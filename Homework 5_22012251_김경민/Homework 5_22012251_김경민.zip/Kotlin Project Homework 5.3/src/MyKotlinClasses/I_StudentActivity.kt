package MyKotlinClasses

interface I_StudentActivity { // 인터페이스
    fun study()
}