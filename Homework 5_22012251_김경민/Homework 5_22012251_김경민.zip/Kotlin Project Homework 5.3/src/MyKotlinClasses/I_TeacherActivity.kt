package MyKotlinClasses

interface I_TeacherActivity { // 인터페이스
    fun teach()
}