package MyKotlinClasses

interface I_PersonActivity { // 인터페이스
    fun talk()
    fun listen()
    fun move()
}
